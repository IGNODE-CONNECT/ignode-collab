# bccd > bccd-m0qhv-wfub5
https://universe.roboflow.com/ig-workspace/bccd-m0qhv-wfub5

Provided by a Roboflow user
License: CC BY 4.0

